# **App Name**: TapStar

## Core Features:

- Falling Object Generation: Generate colored circles at an increasing pace throughout the game.
- Tap Detection: Detect taps on the circles and award points accordingly.
- Combo Bonus: Award extra points for tapping three circles of the same color in a row, using an LLM tool to reason about when the combo bonus can be applied.
- Score Tracking: Track and display the player's current score.
- Timer: Implement a 3-minute timer that ends the game.
- Leaderboard: Display daily, weekly and all-time leaderboards.
- Game Speed Adjustment: Increase the falling speed of circles every 15 seconds.

## Style Guidelines:

- Background color: Dark grey (#222222) to provide high contrast with the colored circles.
- Primary color: Vibrant yellow (#FFEA00) for the score display and start button, chosen for its high visibility and association with energy and fun. It creates a focal point without overwhelming the interface, complementing the gameplay's action-oriented style.
- Accent color: Bright orange (#FF9100) for combo bonus messages and special circle highlights.
- Body and headline font: 'Space Grotesk' (sans-serif) for a techy, scientific feel, suitable for headlines and short amounts of body text.
- Simple, flat icons for the scoreboard and leaderboard.
- Scoreboard at the top left, timer at the top right, and the play area in the center.
- Subtle pop animation when tapping circles.