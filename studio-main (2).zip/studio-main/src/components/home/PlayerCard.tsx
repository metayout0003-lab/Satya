
'use client';

import { Instagram, Crown, Coins, Link as LinkIcon, Edit } from 'lucide-react';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import type { Player } from '@/lib/types';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import Icon from '../core/Icon';
import { Button } from '../ui/button';

interface PlayerCardProps {
  player: Player;
  title: string;
  onEditLink: (rank: number) => void;
}

const rankColor = (rank: number) => {
  if (rank === 1) return 'border-yellow-400';
  if (rank === 2) return 'border-gray-400';
  if (rank === 3) return 'border-orange-400';
  return 'border-muted-foreground';
};

export default function PlayerCard({ player, title, onEditLink }: PlayerCardProps) {
  const socialLink = player.socialLink || (player.instagram ? `https://instagram.com/${player.instagram}` : null);
  const displayHandle = player.socialLink ? 'Social Link' : (player.instagram ? `@${player.instagram}` : null);

  return (
    <Card
      className={cn(
        'w-40 border-2 bg-card/80 flex flex-col justify-between relative group',
        rankColor(player.rank)
      )}
    >
      <Button
        variant="ghost"
        size="icon"
        className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
        onClick={() => onEditLink(player.rank)}
      >
        <Icon as={Edit} className="h-3 w-3" />
      </Button>
      <CardHeader className="flex-row items-center justify-center space-x-2 pb-2 pt-4">
        {player.rank === 1 && <Crown className="h-4 w-4 text-yellow-400" />}
        <CardTitle className="text-xs font-bold text-primary">{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center gap-1 px-2 pb-2">
        <Avatar className="h-10 w-10">
          <AvatarImage src={player.avatar} alt={player.name} />
          <AvatarFallback className="text-lg">
            {player.name.charAt(0)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 overflow-hidden text-center">
            <p className="text-sm font-bold truncate">{player.name}</p>
        </div>
         <div className="flex items-center gap-3 text-base font-bold">
            <span className="text-primary">{player.score.toLocaleString()}</span>
            {player.goldPoints && (
                <div className="flex items-center gap-1 text-yellow-400 text-sm">
                    <Icon as={Coins} className="h-3 w-3" />
                    <span>{player.goldPoints}</span>
                </div>
            )}
        </div>
      </CardContent>
       <CardFooter className="flex justify-center items-center p-1 h-7">
         {socialLink && (
            <Link
                href={socialLink}
                target="_blank"
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary flex items-center gap-1 text-xs"
            >
                <Icon as={player.instagram ? Instagram : LinkIcon} className="h-3 w-3" />
                <span className="text-[10px] truncate">{displayHandle}</span>
            </Link>
        )}
      </CardFooter>
    </Card>
  );
}

    