import { Star } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface HighScoreDisplayProps {
  score: number;
}

export default function HighScoreDisplay({ score }: HighScoreDisplayProps) {
  return (
    <Card className="w-fit border-primary/50 bg-card/50">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">All-Time High Score</CardTitle>
        <Star className="h-4 w-4 text-primary" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-primary">
          {score.toLocaleString()}
        </div>
      </CardContent>
    </Card>
  );
}
