import { Crown, Trophy } from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import type { Player } from "@/lib/types";
import { cn } from "@/lib/utils";

interface LeaderboardProps {
  title: string;
  players: Player[];
}

const rankColor = (rank: number) => {
  if (rank === 1) return "text-yellow-400";
  if (rank === 2) return "text-gray-400";
  if (rank === 3) return "text-orange-400";
  return "text-muted-foreground";
};

export default function Leaderboard({ title, players }: LeaderboardProps) {
  return (
    <Card className="w-full max-w-md border-primary/30">
      <CardHeader>
        <CardTitle className="flex items-center justify-center gap-2 text-xl font-headline">
          <Trophy className="h-6 w-6 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-4">
          {players.map((player) => (
            <li
              key={player.rank}
              className="flex items-center justify-between gap-4"
            >
              <div className="flex items-center gap-4">
                <span
                  className={cn(
                    "font-bold text-lg w-6 text-center",
                    rankColor(player.rank)
                  )}
                >
                  {player.rank}
                </span>
                <Avatar>
                  <AvatarFallback>{player.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <span className="font-medium">{player.name}</span>
              </div>
              <div className="flex items-center gap-2 font-bold text-primary">
                {player.rank === 1 && (
                  <Crown className="h-5 w-5 text-yellow-400" />
                )}
                <span>{player.score.toLocaleString()}</span>
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
