
'use client';

import { useState } from 'react';
import Image from "next/image";
import { Ticket, Coins } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import Icon from "../core/Icon";
import { useToast } from "@/hooks/use-toast";
import type { Redemption } from "@/lib/types";
import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { doc, getDoc, runTransaction, arrayRemove, arrayUnion } from 'firebase/firestore';
import { db } from '@/lib/firebase';

const REDEMPTION_HISTORY_KEY = 'tapstar-redemption-history'; // This can be moved to user subcollection
const REDEEM_CODES_KEY_PREFIX = 'tapstar-redeem-codes-';

interface PrizeCardProps {
  prizeId: string;
  title: string;
  description: string;
  imageUrl: string;
  imageHint: string;
  cost: number;
  currency: 'gold' | 'silver';
}

export default function PrizeCard({ prizeId, title, description, imageUrl, imageHint, cost, currency }: PrizeCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const router = useRouter();
  const [clickCount, setClickCount] = useState(0);

  const handleAdminAccess = () => {
    if (prizeId === 'silver-to-gold') {
      return;
    }
    
    setClickCount((prevCount) => {
        const newCount = prevCount + 1;
        if (newCount >= 5) {
            router.push(`/admin/redeem-codes?prizeId=${prizeId}`);
            return 0; // Reset after redirecting
        }
        return newCount;
    });
  };
  
  const handleRedeem = async (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering the parent onClick
    
    if (!user) {
        toast({ variant: 'destructive', title: 'Not Logged In', description: 'You must be logged in to redeem prizes.' });
        return;
    }

    try {
      await runTransaction(db, async (transaction) => {
        const userRef = doc(db, 'users', user.uid);
        const userDoc = await transaction.get(userRef);

        if (!userDoc.exists()) {
            throw new Error("User document does not exist!");
        }
        
        const userData = userDoc.data();
        
        if (currency === 'silver') {
            const currentSilver = userData.silverPoints || 0;
            if (currentSilver < cost) {
                throw new Error(`You need ${cost} silver points to exchange.`);
            }
            transaction.update(userRef, {
                silverPoints: currentSilver - cost,
                goldPoints: (userData.goldPoints || 0) + 1,
            });
            toast({ title: 'Exchange Successful!', description: `You exchanged ${cost} silver for 1 gold point.` });
        } else { // Gold prize
            const currentGold = userData.goldPoints || 0;
            if (currentGold < cost) {
                throw new Error(`You need ${cost} gold points for this prize.`);
            }

            const codesRef = doc(db, 'prizeCodes', prizeId);
            const codesDoc = await transaction.get(codesRef);
            
            if (!codesDoc.exists() || !codesDoc.data()?.codes?.length) {
                throw new Error("Sorry, this prize is currently out of stock.");
            }

            const codesArray = codesDoc.data()!.codes;
            const redeemCode = codesArray[0];

            // Update user's points and redemption history
            transaction.update(userRef, { 
                goldPoints: currentGold - cost,
                redemptions: arrayUnion({
                    id: Date.now(),
                    prizeTitle: title,
                    redeemCode: redeemCode,
                    date: new Date().toISOString(),
                })
            });

            // Remove the used code
            transaction.update(codesRef, {
                codes: arrayRemove(redeemCode)
            });

            toast({
              title: "Prize Redeemed!",
              description: (
                <div>
                  <p>Your redeem code is:</p>
                  <p className="font-mono text-lg">{redeemCode}</p>
                </div>
              )
            });
        }
      });
    } catch (error: any) {
       toast({
        variant: "destructive",
        title: "Redemption Failed",
        description: error.message || "An unexpected error occurred."
      })
      console.error("Redemption error", error);
    }
  };

  return (
    <Card className="flex flex-col overflow-hidden transition-transform duration-200 hover:scale-105 h-full" onClick={handleAdminAccess}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-grow flex items-center justify-center">
        <Image
          src={imageUrl}
          alt={title}
          width={400}
          height={200}
          className="rounded-md object-cover"
          data-ai-hint={imageHint}
        />
      </CardContent>
      <CardFooter className="flex-col items-stretch space-y-2 pt-4">
         <div className={cn("flex items-center justify-center font-bold gap-2", 
            currency === 'gold' ? 'text-yellow-400' : 'text-gray-400'
         )}>
            <Icon as={Coins} />
            <span>{cost.toLocaleString()}</span>
         </div>
        <Button className="w-full" onClick={handleRedeem}>
          <Icon as={Ticket} className="mr-2" />
          Redeem Now
        </Button>
      </CardFooter>
    </Card>
  );
}
