
'use client';

import React from 'react';
import { useSettings } from '@/context/SettingsContext';
import { cn } from '@/lib/utils';
import type { LucideProps } from 'lucide-react';

interface IconProps extends Omit<LucideProps, 'size'> {
  as: React.ElementType;
}

const Icon = React.forwardRef<SVGSVGElement, IconProps>(
  ({ as: IconComponent, className, style, ...props }, ref) => {
    const { iconScale } = useSettings();

    const sizeStyle = {
      width: `calc(1.25rem * ${iconScale})`,
      height: `calc(1.25rem * ${iconScale})`,
    };

    return (
      <IconComponent
        ref={ref}
        className={cn('inline-block', className)}
        style={{ ...sizeStyle, ...style }}
        {...props}
      />
    );
  }
);

Icon.displayName = 'Icon';

export default Icon;
