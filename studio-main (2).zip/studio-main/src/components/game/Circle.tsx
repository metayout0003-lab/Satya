
"use client";

import React, { memo } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import type { Circle, CircleColor, CircleType } from "@/lib/types";
import { Star, Minus } from "lucide-react";

interface CircleProps {
  circle: Circle;
  onTap: (circle: Circle) => void;
}

const colorMap: Record<CircleColor, string> = {
  red: "bg-red-500",
  yellow: "bg-yellow-400",
  purple: "bg-purple-500",
  green: "bg-green-500",
  orange: "bg-orange-500",
  violet: "bg-violet-500",
  brown: "bg-yellow-900",
};

const typeStyles: Record<CircleType, string> = {
  normal: "h-20 w-20",
  golden: "h-24 w-24 bg-yellow-400 shadow-[0_0_20px_10px_rgba(255,234,0,0.7)] animate-pulse flex items-center justify-center",
  black: "h-20 w-20 bg-gray-800 border-2 border-gray-600",
  white: "h-20 w-20 bg-white border-2 border-gray-300",
};

const CircleComponent = ({ circle, onTap }: CircleProps) => {
  return (
    <motion.div
      initial={{ scale: 0, y: circle.y, x: circle.x }}
      animate={{ scale: 1 }}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
      style={{
        position: "absolute",
        top: circle.y,
        left: circle.x,
        touchAction: "none",
      }}
      className={cn(
        "rounded-full cursor-pointer transition-all duration-100 ease-out flex items-center justify-center",
        typeStyles[circle.type],
        circle.type === "normal" && colorMap[circle.color],
        circle.tappedOnce && "bg-red-500 animate-pulse border-4 border-red-700"
      )}
      onPointerDown={(e) => {
        e.preventDefault();
        onTap(circle);
      }}
    >
      {circle.type === 'golden' && <Star className="h-12 w-12 text-yellow-900 fill-current" />}
      {circle.type === 'black' && <Minus className="h-10 w-10 text-white" />}
    </motion.div>
  );
};

export default memo(CircleComponent);
