
"use client";

import React, { Suspense } from "react";
import dynamic from 'next/dynamic';
import { Star, Timer as TimerIcon, Home } from "lucide-react";
import { useGameEngine } from "@/hooks/useGameEngine";
import CircleComponent from "./Circle";
import { Button } from "../ui/button";
import Link from "next/link";
import Icon from "../core/Icon";
import { useGameChances } from "@/hooks/useGameChances";
import { Skeleton } from "../ui/skeleton";

const GameOverDialog = dynamic(() => import('./GameOverDialog'));

const GameInfo = ({ icon, value, label }: { icon: React.ReactNode, value: string | number, label: string }) => (
    <div className="flex items-center gap-2 bg-black/50 backdrop-blur-sm p-2 px-4 rounded-lg border border-primary/20 shadow-lg">
        {icon}
        <div className="flex flex-col items-end">
            <span className="text-2xl font-bold text-primary tabular-nums">{value}</span>
            <span className="text-xs text-muted-foreground -mt-1">{label}</span>
        </div>
    </div>
);


export default function GameManager() {
  const {
    status,
    score,
    timeLeft,
    circles,
    comboMessage,
    handleTap,
    startGame,
    resetGame,
  } = useGameEngine();
  
  const { isReady, chances } = useGameChances();


  if (status === "idle") {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 z-20 p-4">
        <h1 className="text-6xl font-bold text-primary mb-8 animate-pulse">Ready?</h1>
        <div className="flex w-full max-w-xs flex-col gap-4 sm:max-w-sm sm:flex-row">
          <Button onClick={startGame} size="lg" className="h-16 text-2xl flex-1" disabled={!isReady || chances <= 0}>
            {isReady && chances > 0 ? 'Start Game' : 'No Plays Left'}
          </Button>
           <Link href="/" passHref className="flex-1">
              <Button variant="outline" size="lg" className="h-16 w-full text-2xl" onClick={resetGame}>
                <Icon as={Home} className="mr-2" />
                Home
              </Button>
            </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="absolute top-4 left-4 z-10">
        <GameInfo icon={<TimerIcon className="h-8 w-8 text-primary" />} value={timeLeft} label="SECONDS LEFT" />
      </div>
      <div className="absolute top-4 right-4 z-10">
        <GameInfo icon={<Star className="h-8 w-8 text-primary" />} value={score.toLocaleString()} label="SCORE" />
      </div>

      {status === "playing" &&
        circles.map((circle) => (
          <CircleComponent
            key={circle.id}
            circle={circle}
            onTap={handleTap}
          />
        ))}

      {comboMessage && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 text-5xl font-bold text-accent animate-ping">
          {comboMessage}
        </div>
      )}

      <Suspense fallback={<Skeleton className="h-screen w-screen" />}>
        <GameOverDialog
            isOpen={status === "finished"}
            score={score}
            onPlayAgain={() => {
                resetGame();
                startGame();
            }}
        />
      </Suspense>
    </>
  );
}
