
"use client";

import Link from "next/link";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "../ui/button";

interface GameOverDialogProps {
  isOpen: boolean;
  score: number;
  onPlayAgain: () => void;
}

export default function GameOverDialog({
  isOpen,
  score,
  onPlayAgain,
}: GameOverDialogProps) {
  return (
    <AlertDialog open={isOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="text-center text-3xl font-bold text-primary">
            Game Over!
          </AlertDialogTitle>
          <AlertDialogDescription className="text-center text-lg">
            Your final score is:
            <div className="text-5xl font-bold text-white mt-2">
              {score.toLocaleString()}
            </div>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="flex-col gap-4 sm:flex-col sm:space-x-0">
          <AlertDialogAction onClick={onPlayAgain} className="w-full h-12 text-lg">
            Play Again
          </AlertDialogAction>
          <Link href="/" className="w-full">
            <Button variant="outline" className="w-full h-12 text-lg">
              Back to Home
            </Button>
          </Link>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
