
"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import * as Tone from "tone";
import type { Circle, GameStatus } from "@/lib/types";
import { checkComboBonus } from "@/app/game/actions";
import {
  GAME_DURATION,
  POINTS_NORMAL,
  POINTS_GOLDEN,
  POINTS_BLACK,
  POINTS_WHITE_PENALTY,
  COMBO_BONUS_POINTS,
  CIRCLE_COLORS,
  SPEED_INCREASE_INTERVAL,
  INITIAL_FALL_SPEED,
  FALL_SPEED_INCREMENT,
  INITIAL_SPAWN_RATE,
  SPAWN_RATE_DECREMENT,
  HIGH_SCORE_KEY,
} from "@/lib/game-constants";
import { useGameChances } from "./useGameChances";
import { auth, db } from "@/lib/firebase";
import { doc, updateDoc, getDoc } from "firebase/firestore";

export function useGameEngine() {
  const [status, setStatus] = useState<GameStatus>("idle");
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(GAME_DURATION);
  const [circles, setCircles] = useState<Circle[]>([]);
  const [lastTaps, setLastTaps] = useState<string[]>([]);
  const [comboMessage, setComboMessage] = useState<string | null>(null);

  const { chances, decrementChances, isReady } = useGameChances();

  const fallSpeed = useRef(INITIAL_FALL_SPEED);
  const spawnRate = useRef(INITIAL_SPAWN_RATE);
  const gameIntervalRef = useRef<NodeJS.Timeout>();
  const spawnTimeoutRef = useRef<NodeJS.Timeout>();
  const speedIntervalRef = useRef<NodeJS.Timeout>();
  const animationFrameRef = useRef<number>();
  const synth = useRef<Tone.Synth | null>(null);

  // --- Sound Effects ---
  useEffect(() => {
    synth.current = new Tone.Synth({
        oscillator: { type: 'sine' },
        envelope: { attack: 0.005, decay: 0.1, sustain: 0.3, release: 0.1 }
    }).toDestination();
    
    // Cleanup all timers and animation frames when the component unmounts
    return () => {
      clearAllTimers();
    };
  }, []);

  const playSound = (note: string, duration: string) => {
    if (synth.current && Tone.context.state === 'running') {
      synth.current.triggerAttackRelease(note, duration);
    }
  };

  // --- Game Mechanics ---
  const spawnCircle = useCallback(() => {
    const screenWidth = window.innerWidth;
    const typeChance = Math.random();
    let type: Circle["type"] = "normal";
    if (typeChance > 0.98) type = "golden"; // 2% chance
    else if (typeChance > 0.93) type = "black"; // 5% chance
    else if (typeChance > 0.88) type = "white"; // 5% chance


    const newCircle: Circle = {
      id: Date.now() + Math.random(),
      x: Math.random() * (screenWidth - 80),
      y: -80,
      color: CIRCLE_COLORS[Math.floor(Math.random() * CIRCLE_COLORS.length)],
      type,
    };
    setCircles((prev) => [...prev, newCircle]);
  }, []);

  const updateGame = useCallback(() => {
    setCircles((prevCircles) =>
      prevCircles
        .map((c) => ({ ...c, y: c.y + (c.tappedOnce ? fallSpeed.current * 1.5 : fallSpeed.current) }))
        .filter((c) => c.y < window.innerHeight)
    );
    animationFrameRef.current = requestAnimationFrame(updateGame);
  }, []);
  
  // --- Game State Management ---
  const clearAllTimers = () => {
    if (gameIntervalRef.current) clearInterval(gameIntervalRef.current);
    if (spawnTimeoutRef.current) clearTimeout(spawnTimeoutRef.current);
    if (speedIntervalRef.current) clearInterval(speedIntervalRef.current);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
  }

  const startGame = useCallback(() => {
    if (!isReady || chances <= 0 || status === 'playing') return;

    if (Tone.context.state !== 'running') {
        Tone.start();
    }

    clearAllTimers();
    setScore(0);
    setTimeLeft(GAME_DURATION);
    setCircles([]);
    setLastTaps([]);
    setComboMessage(null);
    fallSpeed.current = INITIAL_FALL_SPEED;
    spawnRate.current = INITIAL_SPAWN_RATE;

    setStatus("playing");
    
    gameIntervalRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearAllTimers();
          setStatus("finished");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    const scheduleSpawn = () => {
        spawnCircle();
        spawnTimeoutRef.current = setTimeout(scheduleSpawn, spawnRate.current);
    }
    scheduleSpawn();

    speedIntervalRef.current = setInterval(() => {
        fallSpeed.current += FALL_SPEED_INCREMENT;
        spawnRate.current = Math.max(50, spawnRate.current - SPAWN_RATE_DECREMENT);
    }, SPEED_INCREASE_INTERVAL);

    animationFrameRef.current = requestAnimationFrame(updateGame);
  }, [spawnCircle, updateGame, isReady, chances, status]);

  const resetGame = useCallback(() => {
    clearAllTimers();
    setStatus("idle");
  }, []);

  const handleTap = useCallback((circle: Circle) => {
      if (circle.type === 'white') {
        if (circle.tappedOnce) {
          // Second tap on a white circle
          setScore(s => Math.max(0, s + POINTS_WHITE_PENALTY));
          setCircles(prev => prev.filter(c => c.id !== circle.id));
          playSound('A2', '4n');
          if (navigator.vibrate) navigator.vibrate([200, 50, 200]);
        } else {
          // First tap on a white circle
          setCircles(prev => prev.map(c => c.id === circle.id ? { ...c, tappedOnce: true } : c));
          playSound('G4', '16n');
          if (navigator.vibrate) navigator.vibrate(50);
        }
        return;
      }

      setCircles((prev) => prev.filter((c) => c.id !== circle.id));

      let points = 0;
      let note = 'C4';
      switch (circle.type) {
          case 'normal':
              points = POINTS_NORMAL;
              note = 'C5';
              break;
          case 'golden':
              points = POINTS_GOLDEN;
              note = 'G5';
              break;
          case 'black':
              points = POINTS_BLACK;
              note = 'C3';
              break;
      }
      setScore((s) => Math.max(0, s + points));
      playSound(note, '8n');
      if (navigator.vibrate) navigator.vibrate(50);
      
      if (circle.type === 'normal') {
        const updatedTaps = [...lastTaps, circle.color].slice(-3);
        setLastTaps(updatedTaps);

        if (updatedTaps.length === 3) {
            checkComboBonus(updatedTaps).then(comboResult => {
              if (comboResult?.awardBonus) {
                  setScore(s => s + COMBO_BONUS_POINTS);
                  setComboMessage(`+${COMBO_BONUS_POINTS} COMBO!`);
                  playSound('E6', '8n');
                  setTimeout(() => setComboMessage(null), 1000);
              }
            });
            // A sequence of 3 has been evaluated, so we must reset to start a new sequence.
            // This fixes a bug where a failing combo didn't reset the counter.
            setLastTaps([]);
        }
      } else {
        // Reset combo for any non-normal tap
        setLastTaps([]);
      }
  }, [lastTaps]);
  
  const saveHighScore = useCallback(async (newScore: number) => {
    if (!auth.currentUser) {
        // Save to local storage for non-logged-in users
        try {
            const storedHighScore = localStorage.getItem(HIGH_SCORE_KEY);
            const highScore = storedHighScore ? JSON.parse(storedHighScore) : 0;
            if (newScore > highScore) {
                localStorage.setItem(HIGH_SCORE_KEY, JSON.stringify(newScore));
                window.dispatchEvent(new StorageEvent('storage', { key: HIGH_SCORE_KEY, newValue: String(newScore) }));
            }
        } catch (error) {
            console.error("Failed to save high score to local storage", error);
        }
        return;
    }

    // Save to Firestore for logged-in users
    try {
        const userRef = doc(db, 'users', auth.currentUser.uid);
        const userDoc = await getDoc(userRef);
        const currentHighScore = userDoc.exists() ? userDoc.data().highScore || 0 : 0;
        
        if (newScore > currentHighScore) {
            await updateDoc(userRef, { highScore: newScore });
        }
    } catch (error) {
        console.error("Failed to save high score to Firestore", error);
    }
  }, []);

  useEffect(() => {
      if (status === 'finished') {
          clearAllTimers();
          saveHighScore(score);
          decrementChances();
      }
  }, [status, score, saveHighScore, decrementChances]);

  return { status, score, timeLeft, circles, comboMessage, handleTap, startGame, resetGame };
}

    