
'use client';

import { useState, useEffect, useCallback } from 'react';

const CHANCES_KEY = 'tapstar-chances-left';
const LAST_RESET_KEY = 'tapstar-last-chance-reset-date';
const TOTAL_CHANCES = 14;

export function useGameChances() {
  const [chances, setChances] = useState(TOTAL_CHANCES);
  const [isReady, setIsReady] = useState(false);

  const checkAndResetChances = useCallback(() => {
    try {
      const lastResetDateStr = localStorage.getItem(LAST_RESET_KEY);
      const today = new Date().toISOString().split('T')[0];

      if (lastResetDateStr !== today) {
        localStorage.setItem(CHANCES_KEY, String(TOTAL_CHANCES));
        localStorage.setItem(LAST_RESET_KEY, today);
        setChances(TOTAL_CHANCES);
      } else {
        const savedChances = localStorage.getItem(CHANCES_KEY);
        setChances(savedChances ? parseInt(savedChances, 10) : TOTAL_CHANCES);
      }
    } catch (error) {
      console.error('Failed to manage game chances in localStorage', error);
      setChances(TOTAL_CHANCES);
    } finally {
        setIsReady(true);
    }
  }, []);

  useEffect(() => {
    checkAndResetChances();
    // Optional: Add a listener for when the tab becomes visible again
    const handleVisibilityChange = () => {
        if (document.visibilityState === 'visible') {
            checkAndResetChances();
        }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
        document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [checkAndResetChances]);
  
  const decrementChances = useCallback(() => {
    setChances(prevChances => {
      const newChances = Math.max(0, prevChances - 1);
      try {
        localStorage.setItem(CHANCES_KEY, String(newChances));
      } catch (error) {
         console.error('Failed to save chances to localStorage', error);
      }
      return newChances;
    });
  }, []);

  return { chances, decrementChances, isReady, checkAndResetChances };
}

    