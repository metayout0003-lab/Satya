
'use client';

import Link from 'next/link';
import { Home } from 'lucide-react';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import Icon from '@/components/core/Icon';
import PrizeCard from '@/components/prizes/PrizeCard';
import { Separator } from '@/components/ui/separator';

export default function PrizesPage() {
  return (
    <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <Card className="w-full max-w-5xl">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl">Prizes</CardTitle>
          <CardDescription>
            Redeem your points for amazing prizes!
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          <div>
            <h3 className="mb-4 text-center text-xl font-semibold text-primary">Google Play Vouchers</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <PrizeCard
                prizeId="google-play-15"
                title="₹15 Google Play Voucher"
                description="Get a ₹15 voucher for the Play Store."
                imageUrl="https://picsum.photos/seed/gp15/400/200"
                imageHint="gift card"
                cost={75}
                currency="gold"
              />
              <PrizeCard
                prizeId="google-play-29"
                title="₹29 Google Play Voucher"
                description="Get a ₹29 voucher for the Play Store."
                imageUrl="https://picsum.photos/seed/gp29/400/200"
                imageHint="google play"
                cost={145}
                currency="gold"
              />
              <PrizeCard
                prizeId="google-play-50"
                title="₹50 Google Play Voucher"
                description="Get a ₹50 voucher for the Play Store."
                imageUrl="https://picsum.photos/seed/gp50/400/200"
                imageHint="rewards"
                cost={250}
                currency="gold"
              />
            </div>
          </div>

          <Separator />

          <div>
             <h3 className="mb-4 text-center text-xl font-semibold text-gray-400">Point Exchange</h3>
            <div className="flex justify-center">
              <div className="w-full md:w-1/3">
                <PrizeCard
                  prizeId="silver-to-gold"
                  title="Exchange Silver Points"
                  description="120 Silver Points = 1 Gold Point"
                  imageUrl="https://picsum.photos/seed/exchange/400/200"
                  imageHint="silver coins"
                  cost={120}
                  currency="silver"
                />
              </div>
            </div>
          </div>

          <div className="mt-8 flex justify-center">
            <Link href="/" passHref>
              <Button variant="outline">
                <Icon as={Home} className="mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
