
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Home, History } from 'lucide-react';
import { format } from 'date-fns';
import { doc, onSnapshot } from 'firebase/firestore';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import Icon from '@/components/core/Icon';
import type { Redemption } from '@/lib/types';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/context/AuthContext';
import { db } from '@/lib/firebase';
import { Skeleton } from '@/components/ui/skeleton';

export default function ActivitiesPage() {
  const { user, loading } = useAuth();
  const [redemptionHistory, setRedemptionHistory] = useState<Redemption[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (loading) return; // Wait for auth state to resolve

    if (!user) {
      setIsLoading(false);
      return;
    }

    const userRef = doc(db, 'users', user.uid);
    const unsubscribe = onSnapshot(userRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        // Sort by date, newest first
        const sortedHistory = (data.redemptions || []).sort(
          (a: Redemption, b: Redemption) => new Date(b.date).getTime() - new Date(a.date).getTime()
        );
        setRedemptionHistory(sortedHistory);
      }
      setIsLoading(false);
    });

    return () => unsubscribe(); // Cleanup listener
  }, [user, loading]);

  if (!user && !loading) {
    return (
       <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
           <Card className="w-full max-w-md text-center">
               <CardHeader>
                   <CardTitle>Access Denied</CardTitle>
                   <CardDescription>You must be logged in to view your history.</CardDescription>
               </CardHeader>
               <CardContent>
                    <Link href="/" passHref>
                     <Button>
                       <Icon as={Home} className="mr-2" />
                       Return to Home
                     </Button>
                   </Link>
               </CardContent>
           </Card>
       </main>
    );
  }

  return (
    <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <Card className="w-full max-w-3xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Icon as={History} />
            My Redemption History
          </CardTitle>
          <CardDescription>
            A personal record of all your prize redemptions.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[60vh]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Prize</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Your Code</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                      <TableCell className="text-right"><Skeleton className="h-5 w-24 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : redemptionHistory.length > 0 ? (
                  redemptionHistory.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>{item.prizeTitle}</TableCell>
                      <TableCell>{format(new Date(item.date), 'PPp')}</TableCell>
                      <TableCell className="text-right font-mono">{item.redeemCode}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={3} className="h-24 text-center">
                      No activities yet. Go redeem some prizes!
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </ScrollArea>
          <div className="mt-6 flex justify-center">
            <Link href="/" passHref>
              <Button variant="ghost">
                <Icon as={Home} className="mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
