'use server';

import { z } from 'zod';

const passwordSchema = z.string().min(1, 'Password is required');

export async function verifyPassword(password: string): Promise<boolean> {
  try {
    const validatedPassword = passwordSchema.parse(password);
    // Securely compare the provided password with the one in environment variables.
    return validatedPassword === process.env.ADMIN_PASSWORD;
  } catch (error) {
    // If validation fails, deny access.
    return false;
  }
}
