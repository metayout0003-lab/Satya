
'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import Link from 'next/link';
import { Home, KeyRound, PlusCircle, Trash2 } from 'lucide-react';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import Icon from '@/components/core/Icon';
import { verifyPassword } from './actions';

const AUTH_KEY = 'tapstar-admin-auth';
const REDEEM_CODES_KEY_PREFIX = 'tapstar-redeem-codes-';

const passwordSchema = z.object({
  password: z.string().min(1, 'Password is required'),
});

const codeSchema = z.object({
    code: z.string().min(1, 'Code is required.').max(50, 'Code must be 50 characters or less.'),
});

type PasswordFormValues = z.infer<typeof passwordSchema>;
type CodeFormValues = z.infer<typeof codeSchema>;

const prizeIdToName: Record<string, string> = {
    'google-play-15': '₹15 Google Play Voucher',
    'google-play-29': '₹29 Google Play Voucher',
    'google-play-50': '₹50 Google Play Voucher',
    'silver-to-gold': 'Silver to Gold Exchange',
}

export default function RedeemCodesAdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentCodes, setCurrentCodes] = useState<string[]>([]);
  const searchParams = useSearchParams();
  const { toast } = useToast();

  const prizeId = searchParams.get('prizeId') || 'google-play-15';
  const prizeName = prizeIdToName[prizeId] || 'Unknown Prize';
  const codesKey = `${REDEEM_CODES_KEY_PREFIX}${prizeId}`;

  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      password: '',
    },
  });

  const codeForm = useForm<CodeFormValues>({
    resolver: zodResolver(codeSchema),
    defaultValues: {
      code: '',
    },
  });

  useEffect(() => {
    try {
        const authStatus = sessionStorage.getItem(AUTH_KEY);
        if (authStatus === 'true') {
            setIsAuthenticated(true);
        }
    } catch (error) {
        // This can happen in SSR or if sessionStorage is disabled.
        console.error('Could not access session storage', error);
    }
  }, []);

  useEffect(() => {
      if (isAuthenticated) {
          loadCodes();
      }
  }, [isAuthenticated, prizeId]);
  
  const loadCodes = () => {
    try {
        const savedCodes = localStorage.getItem(codesKey);
        setCurrentCodes(savedCodes ? JSON.parse(savedCodes) : []);
    } catch (error) {
        console.error('Failed to load codes from local storage', error);
        setCurrentCodes([]);
    }
  }

  const handlePasswordSubmit = async (data: PasswordFormValues) => {
    const isPasswordCorrect = await verifyPassword(data.password);
    if (isPasswordCorrect) {
      try {
        sessionStorage.setItem(AUTH_KEY, 'true');
        setIsAuthenticated(true);
        toast({ title: 'Authentication successful!' });
      } catch (error) {
        console.error('Could not access session storage', error);
        toast({ variant: 'destructive', title: 'Session storage is unavailable.' });
      }
    } else {
      toast({ variant: 'destructive', title: 'Incorrect password.' });
      passwordForm.reset();
    }
  };

  const handleCodeSubmit = (data: CodeFormValues) => {
    try {
      const newCode = data.code.trim();
      if (!newCode) {
        toast({ variant: 'destructive', title: 'Invalid code entered.'});
        return;
      }
      const updatedCodes = [...currentCodes, newCode];
      localStorage.setItem(codesKey, JSON.stringify(updatedCodes));
      setCurrentCodes(updatedCodes);
      codeForm.reset();
      toast({
        title: 'Code Added!',
        description: `A new code has been added for ${prizeName}.`,
      });
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'Failed to save code.' });
      console.error('Failed to save code', error);
    }
  };
  
  const deleteCode = (index: number) => {
      try {
          const updatedCodes = currentCodes.filter((_, i) => i !== index);
          localStorage.setItem(codesKey, JSON.stringify(updatedCodes));
          setCurrentCodes(updatedCodes);
          toast({ title: 'Code deleted!' });
      } catch (error) {
          toast({ variant: 'destructive', title: 'Error', description: 'Failed to delete code.' });
          console.error('Failed to delete code', error);
      }
  }

  if (!isAuthenticated) {
    return (
      <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Icon as={KeyRound} />
              Admin Access Required
            </CardTitle>
            <CardDescription>
              Please enter the password to manage redeem codes.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...passwordForm}>
              <form onSubmit={passwordForm.handleSubmit(handlePasswordSubmit)} className="space-y-4">
                <FormField
                  control={passwordForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Enter password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full">
                  Authenticate
                </Button>
              </form>
            </Form>
            <div className="mt-6 flex justify-center">
                <Link href="/prizes" passHref>
                <Button variant="ghost">
                    Cancel
                </Button>
                </Link>
            </div>
          </CardContent>
        </Card>
      </main>
    );
  }

  return (
    <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Manage Redeem Codes</span>
            <Link href="/" passHref>
                <Button variant="ghost" size="sm">
                    <Icon as={Home} className="mr-2"/>
                    Home
                </Button>
            </Link>
          </CardTitle>
          <CardDescription>
            Add or remove redeem codes for: <span className="font-bold text-primary">{prizeName}</span>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Add Codes Form */}
            <div>
              <h3 className="text-lg font-medium mb-2">Add New Code</h3>
              <Form {...codeForm}>
                <form onSubmit={codeForm.handleSubmit(handleCodeSubmit)} className="space-y-4">
                    <FormField
                    control={codeForm.control}
                    name="code"
                    render={({ field }) => (
                        <FormItem>
                        <FormLabel>New Code</FormLabel>
                        <FormControl>
                            <Input 
                                placeholder="Enter a single redeem code (1-50 characters)" 
                                {...field}
                             />
                        </FormControl>
                         <FormDescription>
                            This code will be given to one player.
                        </FormDescription>
                        <FormMessage />
                        </FormItem>
                    )}
                    />
                    <Button type="submit" className="w-full">
                        <Icon as={PlusCircle} className="mr-2" />
                        Add Code
                    </Button>
                </form>
              </Form>
            </div>

            {/* Current Codes List */}
            <div>
                <h3 className="text-lg font-medium mb-2">Available Codes ({currentCodes.length})</h3>
                {currentCodes.length > 0 ? (
                    <div className="space-y-2 rounded-md border p-2 h-80 overflow-y-auto">
                        {currentCodes.map((code, index) => (
                            <div key={index} className="flex items-center justify-between p-2 bg-muted/50 rounded-md">
                                <span className="font-mono text-sm">{code}</span>
                                <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive" onClick={() => deleteCode(index)}>
                                    <Icon as={Trash2} className="h-4 w-4"/>
                                </Button>
                            </div>
                        ))}
                    </div>
                ): (
                    <div className="flex items-center justify-center h-80 rounded-md border border-dashed">
                        <p className="text-muted-foreground">No codes available.</p>
                    </div>
                )}
            </div>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
