
'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { Home, Coins, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import Icon from '@/components/core/Icon';
import { useToast } from '@/hooks/use-toast';

const SILVER_POINTS_KEY = 'tapstar-silver-points';
const DAILY_REFERRAL_COUNT_KEY = 'tapstar-daily-referral-count';
const LAST_REFERRAL_RESET_KEY = 'tapstar-last-referral-reset-date';
const MAX_DAILY_REFERRALS = 4;

export default function ReferPage() {
  const [silverPoints, setSilverPoints] = useState(0);
  const [referralsToday, setReferralsToday] = useState(0);
  const { toast } = useToast();

  const checkAndResetReferrals = useCallback(() => {
    try {
      const lastResetDate = localStorage.getItem(LAST_REFERRAL_RESET_KEY);
      const today = new Date().toISOString().split('T')[0];

      if (lastResetDate !== today) {
        localStorage.setItem(DAILY_REFERRAL_COUNT_KEY, '0');
        localStorage.setItem(LAST_REFERRAL_RESET_KEY, today);
        setReferralsToday(0);
      } else {
        const savedReferrals = localStorage.getItem(DAILY_REFERRAL_COUNT_KEY);
        setReferralsToday(savedReferrals ? parseInt(savedReferrals, 10) : 0);
      }
    } catch (error) {
      console.error('Failed to manage daily referrals in localStorage', error);
      setReferralsToday(0);
    }
  }, []);

  useEffect(() => {
    checkAndResetReferrals();

    const savedPoints = localStorage.getItem(SILVER_POINTS_KEY);
    if (savedPoints) {
      setSilverPoints(parseInt(savedPoints, 10));
    }
    
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === SILVER_POINTS_KEY) {
        setSilverPoints(e.newValue ? parseInt(e.newValue, 10) : 0);
      }
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };

  }, [checkAndResetReferrals]);

  const handleReferral = () => {
    if (referralsToday >= MAX_DAILY_REFERRALS) {
      toast({
        variant: 'destructive',
        title: 'Daily Limit Reached',
        description: 'You can only refer 4 friends per day. Please try again tomorrow.',
      });
      return;
    }

    const newPoints = silverPoints + 30;
    const newReferralCount = referralsToday + 1;

    try {
      setSilverPoints(newPoints);
      setReferralsToday(newReferralCount);
      localStorage.setItem(SILVER_POINTS_KEY, String(newPoints));
      localStorage.setItem(DAILY_REFERRAL_COUNT_KEY, String(newReferralCount));
      
      window.dispatchEvent(new StorageEvent('storage', { key: SILVER_POINTS_KEY, newValue: String(newPoints) }));

      toast({
        title: 'Referral Link Shared!',
        description: (
          <div>
            <p>You earned 30 Silver Points!</p>
            <p className="text-xs text-muted-foreground">(This is a simulation.)</p>
          </div>
        ),
      });
    } catch (error) {
        console.error("Failed to update points/referrals", error);
        toast({
            variant: "destructive",
            title: "Error",
            description: "Could not process referral. Please try again.",
        });
    }
  };

  const referralsLeft = MAX_DAILY_REFERRALS - referralsToday;

  return (
    <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Icon as={Share2} className="text-primary" />
            Refer a Friend
          </CardTitle>
          <CardDescription>
            Earn Silver Points by referring your friends.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center space-y-2 rounded-lg border bg-card p-6">
            <p className="text-muted-foreground">Your Silver Points Balance</p>
            <p className="text-5xl font-bold text-gray-400">{silverPoints}</p>
          </div>

          <div className="space-y-2 text-center">
            <Button className="w-full" onClick={handleReferral} disabled={referralsLeft <= 0}>
              <Icon as={Share2} className="mr-2" />
              Refer a Friend ({referralsLeft} left today)
            </Button>
            <p className="text-sm text-muted-foreground">
              {referralsLeft > 0
                ? 'Earn 30 points for each referral!'
                : 'You have reached your daily referral limit.'}
            </p>
          </div>
          
           <div className="rounded-lg border bg-card p-4 text-center">
             <p className="text-lg font-bold">
              <span className="text-gray-400">120 Silver Points</span> = <span className="text-yellow-400">1 Gold Point</span>
            </p>
            <p className="text-xs text-muted-foreground mt-1">(You can redeem on the Prizes page)</p>
          </div>

          <div className="mt-6 flex justify-center">
            <Link href="/" passHref>
              <Button variant="ghost">
                <Icon as={Home} className="mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
