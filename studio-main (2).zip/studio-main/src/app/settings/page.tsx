
'use client';

import { Star, Home } from 'lucide-react';
import Link from 'next/link';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { useSettings } from '@/context/SettingsContext';
import Icon from '@/components/core/Icon';

const ICON_SIZE_PRESETS = {
  Small: 0.8,
  Medium: 1,
  Large: 1.2,
};

export default function SettingsPage() {
  const { iconScale, setIconScale } = useSettings();

  const handleSliderChange = (value: number[]) => {
    setIconScale(value[0]);
  };

  return (
    <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Settings</CardTitle>
          <CardDescription>
            Customize the look and feel of the application.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Icon Size</h3>
            <p className="text-sm text-muted-foreground">
              Adjust the size of icons throughout the app.
            </p>

            {/* Presets */}
            <div className="flex space-x-2">
              {(Object.keys(ICON_SIZE_PRESETS) as Array<keyof typeof ICON_SIZE_PRESETS>).map(preset => (
                <Button
                  key={preset}
                  variant={iconScale === ICON_SIZE_PRESETS[preset] ? 'default' : 'outline'}
                  onClick={() => setIconScale(ICON_SIZE_PRESETS[preset])}
                >
                  {preset}
                </Button>
              ))}
            </div>

            {/* Advanced Slider */}
            <div className="space-y-2">
              <label htmlFor="icon-size-slider" className="text-sm font-medium">
                Advanced
              </label>
              <Slider
                id="icon-size-slider"
                min={0.6}
                max={1.8}
                step={0.1}
                value={[iconScale]}
                onValueChange={handleSliderChange}
              />
              <p className="text-right text-sm text-muted-foreground">
                {iconScale.toFixed(1)}x
              </p>
            </div>
          </div>

          {/* Live Preview */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Live Preview</h3>
            <div className="flex items-center justify-center rounded-md border border-dashed p-8">
              <div className="flex items-center space-x-4 text-foreground">
                <Icon as={Star} />
                <span style={{ fontSize: `${iconScale}rem` }}>
                  Sample Text
                </span>
              </div>
            </div>
          </div>
           <div className="mt-6 flex justify-center">
            <Link href="/" passHref>
              <Button variant="outline">
                <Icon as={Home} className="mr-2" />
                Return to Home
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
