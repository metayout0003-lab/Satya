"use server";

import {
  shouldAwardComboBonus,
  type ComboBonusOutput,
} from "@/ai/flows/combo-bonus-reasoning";

export async function checkComboBonus(
  lastThreeTaps: string[]
): Promise<ComboBonusOutput | null> {
  if (lastThreeTaps.length !== 3) {
    return null;
  }
  try {
    const result = await shouldAwardComboBonus({ lastThreeTaps });
    return result;
  } catch (error) {
    console.error("Error checking combo bonus:", error);
    return { awardBonus: false, reason: "Error checking bonus." };
  }
}
