import GameManager from '@/components/game/GameManager';

export default function GamePage() {
  return (
    <main className="relative h-screen w-screen overflow-hidden bg-black font-headline">
      <GameManager />
    </main>
  );
}
