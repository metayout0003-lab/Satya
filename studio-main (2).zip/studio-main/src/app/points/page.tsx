
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Home, Coins } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import Icon from '@/components/core/Icon';
import { useAuth } from '@/context/AuthContext';
import { db } from '@/lib/firebase';
import { doc, onSnapshot } from 'firebase/firestore';
import { Skeleton } from '@/components/ui/skeleton';

const PointsSkeleton = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="flex flex-col items-center space-y-2 rounded-lg border-2 border-yellow-400 bg-card p-6 shadow-lg">
            <Skeleton className="h-5 w-24" />
            <div className="flex items-center gap-2">
                <Icon as={Coins} className="h-10 w-10 text-yellow-400" />
                <Skeleton className="h-12 w-20" />
            </div>
            <Skeleton className="h-4 w-40" />
        </div>
        <div className="flex flex-col items-center space-y-2 rounded-lg border-2 border-gray-400 bg-card p-6 shadow-lg">
            <Skeleton className="h-5 w-28" />
            <div className="flex items-center gap-2">
                <Icon as={Coins} className="h-10 w-10 text-gray-400" />
                <Skeleton className="h-12 w-20" />
            </div>
            <Skeleton className="h-4 w-40" />
        </div>
    </div>
);

export default function PointsPage() {
  const { user } = useAuth();
  const [silverPoints, setSilverPoints] = useState(0);
  const [goldPoints, setGoldPoints] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const userRef = doc(db, 'users', user.uid);
    
    const unsubscribe = onSnapshot(userRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setSilverPoints(data.silverPoints || 0);
        setGoldPoints(data.goldPoints || 0);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  if (!user && !loading) {
    return (
       <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
           <Card className="w-full max-w-md text-center">
               <CardHeader>
                   <CardTitle>Access Denied</CardTitle>
                   <CardDescription>You must be logged in to view your points.</CardDescription>
               </CardHeader>
               <CardContent>
                    <Link href="/" passHref>
                     <Button>
                       <Icon as={Home} className="mr-2" />
                       Return to Home
                     </Button>
                   </Link>
               </CardContent>
           </Card>
       </main>
    )
 }

  return (
    <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Icon as={Coins} className="text-primary" />
            My Points
          </CardTitle>
          <CardDescription>
            Your current Gold and Silver Points balance.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {loading ? (
            <PointsSkeleton />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex flex-col items-center space-y-2 rounded-lg border-2 border-yellow-400 bg-card p-6 shadow-lg">
                <p className="text-muted-foreground">Gold Points</p>
                <div className="flex items-center gap-2">
                  <Icon as={Coins} className="h-10 w-10 text-yellow-400" />
                  <p className="text-5xl font-bold text-yellow-400">{goldPoints}</p>
                </div>
                 <p className="text-xs text-center text-muted-foreground mt-2">Earned from daily leaderboard rankings.</p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border-2 border-gray-400 bg-card p-6 shadow-lg">
                <p className="text-muted-foreground">Silver Points</p>
                 <div className="flex items-center gap-2">
                  <Icon as={Coins} className="h-10 w-10 text-gray-400" />
                  <p className="text-5xl font-bold text-gray-400">{silverPoints}</p>
                </div>
                <p className="text-xs text-center text-muted-foreground mt-2">Earned from referring friends.</p>
              </div>
            </div>
          )}
          
           <div className="rounded-lg border bg-card/50 p-4 text-center">
             <p className="text-lg font-bold">
              <span className="text-gray-400">120 Silver Points</span> = <span className="text-yellow-400">1 Gold Point</span>
            </p>
            <p className="text-xs text-muted-foreground mt-1">(You can redeem on the Prizes page)</p>
          </div>

          <div className="mt-6 flex justify-center">
            <Link href="/" passHref>
              <Button variant="ghost">
                <Icon as={Home} className="mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
