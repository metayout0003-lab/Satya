
'use client';

import Link from 'next/link';
import { Home, Gavel, Star, Circle, MinusCircle, Award, Heart, Share2 } from 'lucide-react';
import { motion } from 'framer-motion';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import Icon from '@/components/core/Icon';

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 },
};

export default function RulesPage() {
  return (
    <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <motion.div
        initial="hidden"
        animate="visible"
        variants={cardVariants}
        transition={{ duration: 0.5 }}
      >
        <Card className="w-full max-w-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-3xl">
              <Icon as={Gavel} />
              Game Rules & Info
            </CardTitle>
            <CardDescription>
              Everything you need to know to become a TapStar champion.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible defaultValue="item-1" className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger className="text-xl">
                  Game Rules
                </AccordionTrigger>
                <AccordionContent className="space-y-4 text-base">
                  <p>
                    The goal of TapStar is to score as many points as possible by tapping falling stars within the 3-minute time limit.
                  </p>
                  <ul className="list-disc space-y-2 pl-6">
                    <li>
                      <strong className="text-primary">Game Duration:</strong> Each game lasts for 180 seconds (3 minutes).
                    </li>
                    <li>
                      <strong className="text-primary">Scoring:</strong>
                      <ul className="list-disc space-y-2 pl-6 pt-2">
                        <li>
                          <Icon as={Circle} className="mr-2 text-green-400" />
                          <span className="font-bold">Normal Stars:</span> +10 points.
                        </li>
                        <li>
                          <Icon as={Star} className="mr-2 text-yellow-400" />
                           <span className="font-bold">Golden Stars:</span> +50 points.
                        </li>
                        <li>
                          <Icon as={MinusCircle} className="mr-2 text-red-500" />
                          <span className="font-bold">Black Stars:</span> -20 points.
                        </li>
                         <li>
                          <Icon as={Circle} className="mr-2 text-white" />
                          <span className="font-bold">White Stars:</span> This is a trick star! Tapping it once is a warning. Tapping it a second time deducts <strong className="text-destructive">-49 points</strong>. Avoid tapping it twice!
                        </li>
                      </ul>
                    </li>
                     <li>
                      <strong className="text-primary">Combo Bonus:</strong> Tap three stars of the same color in a row to get a combo bonus of an extra +20 points!
                    </li>
                     <li>
                      <strong className="text-primary">Ranking:</strong> Players are ranked based on their highest score. In case of a tie, the player who achieved the score first will be given the higher rank.
                    </li>
                  </ul>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2">
                <AccordionTrigger className="text-xl">
                  Gold Points
                </AccordionTrigger>
                <AccordionContent className="space-y-4 text-base">
                   <p>
                    Gold Points are a special currency you can earn and exchange for real rewards. You can redeem them on the Prizes page.
                  </p>
                  <div className="rounded-lg border bg-card p-4">
                     <p className="text-center text-lg font-bold">
                      <span className="text-yellow-400">5 Gold Points</span> = <span className="text-primary">₹1 Redeem Code</span>
                    </p>
                  </div>
                   <h4 className="flex items-center gap-2 font-bold text-primary">
                    <Icon as={Award} />
                    Redemption Rules
                  </h4>
                   <ul className="list-disc space-y-2 pl-6">
                    <li>
                      Players can redeem Gold Points only if they achieve a daily rank between <strong className="text-primary">Top 1 – Top 500</strong>.
                    </li>
                    <li>
                      If a player does not reach the Top 500 for <strong className="text-primary">5 consecutive days</strong>, all unredeemed Gold Points will be automatically removed.
                    </li>
                    <li>
                      This rule applies to every player to ensure fairness and encourage active participation.
                    </li>
                   </ul>
                </AccordionContent>
              </AccordionItem>
                 <AccordionItem value="item-4">
                <AccordionTrigger className="text-xl">
                  Silver Points
                </AccordionTrigger>
                <AccordionContent className="space-y-4 text-base">
                   <p>
                    Silver Points are another way to earn rewards in TapStar. You can get them by referring your friends to play the game.
                  </p>
                   <ul className="list-disc space-y-2 pl-6">
                    <li>
                      <strong className="text-primary">Refer a Friend:</strong> Earn <span className="text-gray-400">30 Silver Points</span> for each friend you successfully refer.
                    </li>
                     <li>
                      <strong className="text-primary">Daily Limit:</strong> You can refer a maximum of <span className="text-primary">4 friends</span> each day.
                    </li>
                     <li>
                      <strong className="text-primary">Conversion:</strong> You can convert your Silver Points into Gold Points.
                    </li>
                   </ul>
                    <div className="rounded-lg border bg-card p-4">
                     <p className="text-center text-lg font-bold">
                      <span className="text-gray-400">120 Silver Points</span> = <span className="text-yellow-400">1 Gold Point</span>
                    </p>
                  </div>
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value-="item-3">
                <AccordionTrigger className="text-xl">
                  Daily Plays
                </AccordionTrigger>
                <AccordionContent className="space-y-4 text-base">
                   <p>
                    To ensure fairness and keep the competition exciting, each player gets a limited number of chances to play each day.
                  </p>
                   <ul className="list-disc space-y-2 pl-6">
                    <li>
                      You get <strong className="text-primary">14 chances</strong> to play every day.
                    </li>
                    <li>
                      Your chances reset automatically every 24 hours.
                    </li>
                    <li>
                      Use your chances wisely to get the highest score and climb the leaderboard!
                    </li>
                   </ul>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
            <div className="mt-8 flex justify-center">
              <Link href="/" passHref>
                <Button variant="ghost">
                  <Icon as={Home} className="mr-2" />
                  Back to Home
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </main>
  );
}
