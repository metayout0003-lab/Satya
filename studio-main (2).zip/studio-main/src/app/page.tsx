
'use client';

import Link from 'next/link';
import { Gamepad2, Menu, LogIn, Trophy, Settings, Gift, ChevronDown, ChevronUp, User, Activity, Gavel, Coins, Heart, Share2, History, Save, Star, LogOut } from 'lucide-react';
import { useState, useEffect, useCallback } from 'react';
import { collection, query, orderBy, limit, onSnapshot, DocumentData } from 'firebase/firestore';

import { Button } from '@/components/ui/button';
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarTrigger,
} from '@/components/ui/menubar';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import PlayerCard from '@/components/home/PlayerCard';
import type { Player } from '@/lib/types';
import { cn } from '@/lib/utils';
import Icon from '@/components/core/Icon';
import { Skeleton } from '@/components/ui/skeleton';
import HighScoreDisplay from '@/components/home/HighScoreDisplay';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Progress } from '@/components/ui/progress';
import { useGameChances } from '@/hooks/useGameChances';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import { useAuth } from '@/context/AuthContext';
import { db } from '@/lib/firebase';


const getGoldPointsByRank = (rank: number): number => {
    if (rank === 1) return 36;
    if (rank === 2) return 31;
    if (rank === 3) return 33;
    if (rank <= 59) return 15;
    if (rank <= 100) return 11;
    if (rank <= 500) return 9;
    if (rank <= 1500) return 5;
    if (rank <= 2500) return 3;
    return 0;
}

const rankColor = (rank: number) => {
  if (rank === 1) return 'text-yellow-400';
  if (rank === 2) return 'text-gray-400';
  if (rank === 3) return 'text-orange-400';
  return 'text-muted-foreground';
};

const LeaderboardSkeleton = () => (
    <ul className="space-y-4 pr-4">
        {Array.from({ length: 15 }).map((_, i) => (
            <li key={i} className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                    <Skeleton className="h-6 w-8 rounded-md" />
                    <Skeleton className="h-8 w-8 rounded-full" />
                    <div className="space-y-2">
                        <Skeleton className="h-4 w-24 md:w-32 rounded-md" />
                    </div>
                </div>
                <Skeleton className="h-6 w-16 md:w-20 rounded-md" />
            </li>
        ))}
    </ul>
);

const HIGH_SCORE_KEY = 'tapstar-highscore';
const TOP_PLAYERS_KEY = 'tapstar-top-players';

const SplashAnimation = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="flex h-screen w-screen items-center justify-center bg-background"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: [1, 1.2, 1], opacity: 1, rotate: [0, 180, 360] }}
        transition={{ duration: 2, ease: "easeInOut", repeat: Infinity, repeatType: "loop" }}
      >
        <Icon as={Star} className="h-24 w-24 text-primary" />
      </motion.div>
      <h1 className="sr-only">TapStar</h1>
    </motion.div>
);


export default function Home() {
  const { user, signIn, signOutUser } = useAuth();
  const [leaderboardPlayers, setLeaderboardPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);
  const [highScore, setHighScore] = useState(0);
  const [showSplash, setShowSplash] = useState(true);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(true);
  const { chances, isReady } = useGameChances();
  const { toast } = useToast();

  const [isLinkDialogOpen, setIsLinkDialogOpen] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [newLink, setNewLink] = useState('');
  
  const topPlayers = leaderboardPlayers.slice(0, 3);
  const [top1, top2, top3] = topPlayers;

  useEffect(() => {
    setLoading(true);
    const q = query(collection(db, "users"), orderBy("highScore", "desc"), limit(100));
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const players: Player[] = querySnapshot.docs.map((doc, index) => {
        const data = doc.data() as DocumentData;
        return {
          name: data.name || 'Anonymous',
          score: data.highScore || 0,
          rank: index + 1,
          goldPoints: getGoldPointsByRank(index + 1),
          avatar: data.avatar,
        };
      });
      setLeaderboardPlayers(players);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const updateHighScore = useCallback(() => {
    try {
      const storedHighScore = localStorage.getItem(HIGH_SCORE_KEY);
      if (storedHighScore) {
        setHighScore(JSON.parse(storedHighScore));
      }
    } catch (error) {
        console.error('Failed to parse high score', error);
        setHighScore(0);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500); // Splash screen for 2.5 seconds

    return () => clearTimeout(timer);
  }, []);
  
  useEffect(() => {
    updateHighScore();
    // Listen for storage changes to update high score across tabs
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === HIGH_SCORE_KEY) {
        updateHighScore();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [updateHighScore]);

  const handleEditLink = (rank: number) => {
    if (!user) {
        toast({ variant: 'destructive', title: 'Admin Only', description: 'You must be logged in to edit links.' });
        return;
    }
    // This could be restricted to admins in the future.
    const player = leaderboardPlayers.find(p => p.rank === rank);
    if (player) {
        setEditingPlayer(player);
        setNewLink(player.socialLink || '');
        setIsLinkDialogOpen(true);
    }
  };

  const handleSaveLink = () => {
    if (!editingPlayer) return;

    // In a real app, this should be a Firestore update with security rules.
    const updatedLeaderboard = leaderboardPlayers.map(p => 
        p.rank === editingPlayer.rank 
        ? { ...p, socialLink: newLink }
        : p
    );

    setLeaderboardPlayers(updatedLeaderboard);
    
    try {
        // This is a client-side simulation. For persistence, update Firestore.
        toast({ title: "Link Saved!", description: `The social link for ${editingPlayer.name} has been updated.` });
    } catch(e) {
        console.error("Failed to save link", e);
        toast({ variant: 'destructive', title: 'Error', description: 'Could not save the link.' });
    }

    setIsLinkDialogOpen(false);
    setEditingPlayer(null);
    setNewLink('');
  };

  if (showSplash) {
    return <SplashAnimation />;
  }

  const hasChances = chances > 0;

  return (
    <div className="relative flex flex-col min-h-screen w-full bg-background p-4 font-headline md:p-8">
      {/* Header */}
       <header className="flex items-center justify-between">
        <Menubar className="border-0 bg-transparent">
          <MenubarMenu>
            <MenubarTrigger className="cursor-pointer">
              <Icon as={Menu} />
            </MenubarTrigger>
            <MenubarContent>
                <Link href="/profile">
                  <MenubarItem>
                    <Icon as={User} className="mr-2" />
                    <span>Player Profile</span>
                  </MenubarItem>
                </Link>
                <Link href="/points">
                  <MenubarItem>
                    <Icon as={Coins} className="mr-2" />
                    <span>Points</span>
                  </MenubarItem>
                </Link>
               <Link href="/prizes">
                <MenubarItem>
                  <Icon as={Gift} className="mr-2" />
                  <span>Redeem Prizes</span>
                </MenubarItem>
              </Link>
               <Link href="/refer">
                <MenubarItem>
                  <Icon as={Share2} className="mr-2" />
                  <span>Refer a Friend</span>
                </MenubarItem>
              </Link>
              <Link href="/rules">
                <MenubarItem>
                  <Icon as={Gavel} className="mr-2" />
                  <span>Rules</span>
                </MenubarItem>
              </Link>
                <Link href="/activities">
                    <MenubarItem>
                    <Icon as={History} className="mr-2" />
                    <span>My History</span>
                    </MenubarItem>
                </Link>
              <MenubarItem onSelect={user ? signOutUser : signIn}>
                <Icon as={user ? LogOut : LogIn} className="mr-2" />
                <span>{user ? 'Logout' : 'Google Login'}</span>
              </MenubarItem>
              <Link href="/settings">
                <MenubarItem>
                  <Icon as={Settings} className="mr-2" />
                  <span>Settings</span>
                </MenubarItem>
              </Link>
            </MenubarContent>
          </MenubarMenu>
        </Menubar>
        <div className="flex flex-col items-center">
            {isReady ? (
            <div className="w-48 md:w-64">
              <div className="flex items-center justify-center gap-2 mb-1 text-sm font-medium">
                <Icon as={Heart} className="text-red-500" />
                <span>Daily Plays</span>
                <span className="font-bold">{chances} / 14</span>
              </div>
              <Progress value={(chances / 14) * 100} className="h-2" />
            </div>
          ) : (
             <div className="w-48 md:w-64">
                <Skeleton className="h-4 w-3/4 mb-1 mx-auto" />
                <Skeleton className="h-2 w-full" />
            </div>
          )}
        </div>
        <div className="w-10">{/* Placeholder for right side content */}</div>
      </header>

      {/* Main Content Area */}
      <main className="flex-grow grid grid-cols-1 md:grid-cols-[1fr_auto] gap-8 mt-8">
        {/* Left Column: Top Players & Start Button */}
        <div className="flex flex-col items-center justify-center gap-8">
            <div className="grid grid-cols-2 lg:grid-cols-3 items-start justify-center gap-4">
                {top1 && <PlayerCard player={top1} title="Top 1 Player" onEditLink={handleEditLink} />}
                {top2 && <PlayerCard player={top2} title="Top 2 Player" onEditLink={handleEditLink} />}
                {top3 && <PlayerCard player={top3} title="Top 3 Player" onEditLink={handleEditLink} />}
                <div className="col-span-2 lg:col-span-1 lg:col-start-2">
                    <HighScoreDisplay score={highScore} />
                </div>
            </div>

            <div className="flex flex-col items-center">
                 <Link href={hasChances ? "/game" : "#"} passHref>
                    <Button
                        size="lg"
                        className="h-24 w-64 transform text-4xl font-bold shadow-lg shadow-primary/20 transition-transform duration-200 hover:scale-110 active:scale-100 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:scale-100"
                        disabled={!hasChances}
                        aria-disabled={!hasChances}
                    >
                        <Icon as={Gamepad2} className="mr-4 h-10 w-10" />
                        {hasChances ? 'START' : 'NO PLAYS'}
                    </Button>
                </Link>
                {!hasChances && (
                <p className="mt-4 text-center text-muted-foreground">
                    Come back tomorrow for more chances!
                </p>
                )}
            </div>
        </div>

        {/* Right Column: Leaderboard */}
        <div className="flex items-center justify-center md:justify-end">
          <Collapsible open={isLeaderboardOpen} onOpenChange={setIsLeaderboardOpen} className="w-full max-w-md">
            <Card className="flex h-full max-h-[75vh] flex-col border-primary/30">
                <CollapsibleTrigger asChild>
                    <CardHeader className="flex-row items-center justify-between cursor-pointer">
                        <CardTitle className="flex items-center justify-center gap-2 text-xl font-headline">
                        <Icon as={Trophy} className="text-primary" />
                        Leaderboard
                        </CardTitle>
                        <Button variant="ghost" size="sm">
                            <Icon as={isLeaderboardOpen ? ChevronUp : ChevronDown} />
                        </Button>
                    </CardHeader>
                </CollapsibleTrigger>
                <CollapsibleContent>
                <CardContent className="flex-grow overflow-hidden">
                    <ScrollArea className="h-[60vh]">
                    {loading ? (
                        <LeaderboardSkeleton />
                    ) : (
                        <ul className="space-y-4 pr-4">
                        {leaderboardPlayers.map(player => (
                            <li
                            key={player.rank}
                            className="flex items-center justify-between gap-4"
                            >
                            <div className="flex items-center gap-4">
                                <span
                                className={cn(
                                    'w-8 text-center font-bold',
                                    rankColor(player.rank)
                                )}
                                >
                                {player.rank}
                                </span>
                                <Avatar className="h-8 w-8">
                                  <AvatarImage src={player.avatar} alt={player.name} />
                                  <AvatarFallback>
                                      {player.name.charAt(0)}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="font-medium truncate">{player.name}</span>
                            </div>
                            <div className="flex items-center gap-2 font-bold text-primary">
                                {player.goldPoints && (
                                    <div className="flex items-center gap-1 text-yellow-400">
                                        <Icon as={Coins} className="h-4 w-4" />
                                        <span>{player.goldPoints}</span>
                                    </div>
                                )}
                                <span>{player.score.toLocaleString()}</span>
                            </div>
                            </li>
                        ))}
                        </ul>
                    )}
                    </ScrollArea>
                </CardContent>
                </CollapsibleContent>
            </Card>
          </Collapsible>
        </div>
      </main>

       {/* Edit Link Dialog */}
      <Dialog open={isLinkDialogOpen} onOpenChange={setIsLinkDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Social Link</DialogTitle>
            <DialogDescription>
              Update the social media link for {editingPlayer?.name}. Paste the new link below.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="link" className="text-right">
                Link
              </Label>
              <Input
                id="link"
                value={newLink}
                onChange={(e) => setNewLink(e.target.value)}
                className="col-span-3"
                placeholder="https://example.com/..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleSaveLink}>
              <Icon as={Save} className="mr-2" />
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

    