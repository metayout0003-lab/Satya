
'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { Home, User, Edit, Save, ShieldCheck, Mail } from 'lucide-react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { getStorage, ref, uploadString, getDownloadURL } from 'firebase/storage';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import Icon from '@/components/core/Icon';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/context/AuthContext';
import { db } from '@/lib/firebase';
import { Skeleton } from '@/components/ui/skeleton';

const profileSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters').max(20, 'Name must be at most 20 characters'),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function ProfilePage() {
  const { user, loading } = useAuth();
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: '',
    },
  });

  useEffect(() => {
    if (user) {
      const userRef = doc(db, 'users', user.uid);
      getDoc(userRef).then((docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          form.setValue('name', data.name || user.displayName || 'Guest');
          setAvatarPreview(data.avatar || user.photoURL);
        }
      });
    }
  }, [user, form]);

  const handleAvatarChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: ProfileFormValues) => {
    if (!user) {
      toast({ variant: 'destructive', title: 'Not Logged In', description: 'You must be logged in to update your profile.' });
      return;
    }

    const userRef = doc(db, 'users', user.uid);
    let avatarUrl = null;

    try {
      if (avatarPreview && !avatarPreview.startsWith('http')) {
        // New avatar uploaded, need to save to Firebase Storage
        const storage = getStorage();
        const storageRef = ref(storage, `avatars/${user.uid}`);
        await uploadString(storageRef, avatarPreview, 'data_url');
        avatarUrl = await getDownloadURL(storageRef);
      }

      const profileData: { name: string; avatar?: string } = {
        name: data.name,
      };
      if (avatarUrl) {
        profileData.avatar = avatarUrl;
      }
      
      await updateDoc(userRef, profileData);

      toast({
        title: 'Profile Saved!',
        description: 'Your changes have been saved successfully.',
      });
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to save profile.',
      });
      console.error('Failed to save profile', error);
    }
  };
  
  if (loading) {
    return (
        <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
            <Card className="w-full max-w-md">
                <CardHeader>
                    <Skeleton className="h-8 w-48" />
                    <Skeleton className="h-4 w-full mt-2" />
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="flex flex-col items-center space-y-4">
                        <Skeleton className="h-32 w-32 rounded-full" />
                        <Skeleton className="h-10 w-40" />
                    </div>
                     <Skeleton className="h-10 w-full" />
                     <Skeleton className="h-10 w-full" />
                     <Skeleton className="h-10 w-full" />
                </CardContent>
            </Card>
        </main>
    )
  }

  if (!user) {
     return (
        <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
            <Card className="w-full max-w-md text-center">
                <CardHeader>
                    <CardTitle>Access Denied</CardTitle>
                    <CardDescription>You must be logged in to view your profile.</CardDescription>
                </CardHeader>
                <CardContent>
                     <Link href="/" passHref>
                      <Button>
                        <Icon as={Home} className="mr-2" />
                        Return to Home
                      </Button>
                    </Link>
                </CardContent>
            </Card>
        </main>
     )
  }

  return (
    <main className="container mx-auto flex min-h-screen flex-col items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Icon as={User} />
            Player Profile
          </CardTitle>
          <CardDescription>
            Change your display name and profile picture.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center space-y-4">
            <Avatar className="h-32 w-32 cursor-pointer" onClick={() => fileInputRef.current?.click()}>
              <AvatarImage src={avatarPreview || ''} alt="Player Avatar" />
              <AvatarFallback className="text-4xl">
                {form.getValues('name')?.charAt(0) || user?.displayName?.charAt(0) || 'G'}
              </AvatarFallback>
            </Avatar>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleAvatarChange}
              className="hidden"
              accept="image/png, image/jpeg"
            />
            <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
              <Icon as={Edit} className="mr-2" />
              Change Picture
            </Button>
          </div>

          {user?.uid && (
            <div className="space-y-2 rounded-md border bg-muted p-3">
              <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Icon as={ShieldCheck} />
                Player ID
              </label>
              <p className="font-mono text-center text-lg tracking-widest">{user.uid}</p>
            </div>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Player Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter your name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full">
                <Icon as={Save} className="mr-2" />
                Save Changes
              </Button>
            </form>
          </Form>

          <a href="mailto:tapstar296@gmail.com" className="w-full inline-block">
            <Button variant="outline" className="w-full">
                <Icon as={Mail} className="mr-2" />
                Complain or Query
            </Button>
          </a>

          <div className="mt-6 flex justify-center">
            <Link href="/" passHref>
              <Button variant="ghost">
                <Icon as={Home} className="mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </main>
  );
}
