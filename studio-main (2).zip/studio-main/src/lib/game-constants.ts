
import type { CircleColor } from "./types";

export const GAME_DURATION = 180; // 3 minutes in seconds

export const POINTS_NORMAL = 10;
export const POINTS_GOLDEN = 50;
export const POINTS_BLACK = -20;
export const POINTS_WHITE_PENALTY = -49;
export const COMBO_BONUS_POINTS = 20;

export const CIRCLE_COLORS: CircleColor[] = [
  "red",
  "yellow",
  "purple",
  "green",
  "orange",
  "violet",
  "brown",
];

export const SPEED_INCREASE_INTERVAL = 15000; // 15 seconds in ms
export const INITIAL_FALL_SPEED = 2.25; // pixels per frame
export const FALL_SPEED_INCREMENT = 0.5; // 

export const INITIAL_SPAWN_RATE = 700; // ms
export const SPAWN_RATE_DECREMENT = 50; // ms

export const HIGH_SCORE_KEY = 'tapstar-highscore';

    