// Import the functions you need from the SDKs you need
import { initializeApp, getApps } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  projectId: "flutter-7kq8d",
  appId: "1:786017849561:web:736bc0614924fa2a9c2ec8",
  storageBucket: "flutter-7kq8d.firebasestorage.app",
  apiKey: "AIzaSyDm9Mh7amsASnue0X7Yw2GRqcTcOCVSbjc",
  authDomain: "flutter-7kq8d.firebaseapp.com",
  messagingSenderId: "786017849561",
};

// Initialize Firebase
let app;
if (!getApps().length) {
  app = initializeApp(firebaseConfig);
}

const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };