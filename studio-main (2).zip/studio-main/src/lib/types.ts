
export interface Player {
  name: string;
  score: number;
  rank: number;
  instagram?: string;
  goldPoints?: number;
  socialLink?: string;
  avatar?: string;
}

export type CircleType = "normal" | "golden" | "black" | "white";

export type CircleColor = "red" | "yellow" | "purple" | "green" | "orange" | "violet" | "brown";

export interface Circle {
  id: number;
  x: number;
  y: number;
  color: CircleColor;
  type: CircleType;
  tappedOnce?: boolean;
}

export type GameStatus = "idle" | "playing" | "finished";

export interface Redemption {
  id: number;
  prizeTitle: string;
  redeemCode: string;
  date: string;
}

    