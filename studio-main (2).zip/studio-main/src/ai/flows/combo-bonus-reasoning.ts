// This is a server-side file.
'use server';

/**
 * @fileOverview This file defines a Genkit flow for determining if a combo bonus should be awarded in the TapStar game.
 *
 * It exports:
 * - `shouldAwardComboBonus`: A function to determine if a combo bonus should be awarded based on the last three taps.
 * - `ComboBonusInput`: The input type for the `shouldAwardComboBonus` function.
 * - `ComboBonusOutput`: The output type for the `shouldAwardComboBonus` function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Define the input schema for the combo bonus determination.
const ComboBonusInputSchema = z.object({
  lastThreeTaps: z
    .array(z.string())
    .length(3)
    .describe(
      'An array of the last three tapped circle colors. Must be exactly three elements long.'
    ),
});
export type ComboBonusInput = z.infer<typeof ComboBonusInputSchema>;

// Define the output schema for the combo bonus determination.
const ComboBonusOutputSchema = z.object({
  awardBonus: z
    .boolean()
    .describe(
      'Whether or not a combo bonus should be awarded based on the last three taps.'
    ),
  reason: z
    .string()
    .describe(
      'The reasoning behind the decision to award or not award the combo bonus.'
    ),
});
export type ComboBonusOutput = z.infer<typeof ComboBonusOutputSchema>;

// Exported function to determine if a combo bonus should be awarded.
export async function shouldAwardComboBonus(input: ComboBonusInput): Promise<ComboBonusOutput> {
  return comboBonusFlow(input);
}

// Define the prompt for the LLM to determine if a combo bonus should be awarded.
const comboBonusPrompt = ai.definePrompt({
  name: 'comboBonusPrompt',
  input: {schema: ComboBonusInputSchema},
  output: {schema: ComboBonusOutputSchema},
  prompt: `You are a game referee determining if a player should be awarded a combo bonus.

The game is called TapStar. The player taps falling circles of different colors.

To get a combo bonus, the player must tap three circles of the same color in a row.

Given the last three taps, determine if the player should be awarded a combo bonus and explain your reasoning.

Last Three Taps: {{{lastThreeTaps}}}
`,
});

// Define the Genkit flow for the combo bonus determination.
const comboBonusFlow = ai.defineFlow(
  {
    name: 'comboBonusFlow',
    inputSchema: ComboBonusInputSchema,
    outputSchema: ComboBonusOutputSchema,
  },
  async input => {
    const {output} = await comboBonusPrompt(input);
    return output!;
  }
);
