import { config } from 'dotenv';
config();

import '@/ai/flows/combo-bonus-reasoning.ts';