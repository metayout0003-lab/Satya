
'use client';

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  type ReactNode,
} from 'react';

interface SettingsContextType {
  iconScale: number;
  setIconScale: (scale: number) => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(
  undefined
);

const SETTINGS_STORAGE_KEY = 'tapstar-settings';

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [iconScale, setIconScaleState] = useState<number>(1);

  useEffect(() => {
    const savedSettings = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (savedSettings) {
      try {
        const { iconScale: savedIconScale } = JSON.parse(savedSettings);
        if (typeof savedIconScale === 'number') {
          setIconScaleState(savedIconScale);
        }
      } catch (error) {
        console.error('Failed to parse settings from localStorage', error);
      }
    }
  }, []);

  const setIconScale = (scale: number) => {
    setIconScaleState(scale);
    try {
      const settings = JSON.stringify({ iconScale: scale });
      localStorage.setItem(SETTINGS_STORAGE_KEY, settings);
    } catch (error) {
      console.error('Failed to save settings to localStorage', error);
    }
  };

  useEffect(() => {
    document.documentElement.style.setProperty('--icon-scale', iconScale.toString());
  }, [iconScale]);

  return (
    <SettingsContext.Provider value={{ iconScale, setIconScale }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
